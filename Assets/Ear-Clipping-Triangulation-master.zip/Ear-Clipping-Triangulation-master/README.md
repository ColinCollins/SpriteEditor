# Ear-Clipping-Triangulation

Polygon triangulation using ear clipping algorithm. Supports multiple holes. Quite slow.
Based on algorithm described here: https://www.geometrictools.com/Documentation/TriangulationByEarClipping.pdf
